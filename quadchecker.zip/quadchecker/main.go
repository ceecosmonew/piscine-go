package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func main() {
	add_in := readStdin()
	if add_in == "" {
		fmt.Println("Not a quad function")
		return
	}

	symbol := strings.Split(add_in, "\n")
	if symbol[len(symbol)-1] == "" {
		symbol = symbol[:len(symbol)-1]
	}

	if len(symbol) == 0 {
		fmt.Println("Not a quad function")
		return
	}

	y := len(symbol)
	x := len(symbol[0])

	for _, line := range symbol {
		if len(line) != x {
			fmt.Println("Not a quad function")
			return
		}
	}

	results := []string{}

	if quadA(symbol) {
		results = append(results, format("quadA", x, y))
	}
	if quadB(symbol) {
		results = append(results, format("quadB", x, y))
	}
	if quadC(symbol) {
		results = append(results, format("quadC", x, y))
	}
	if quadD(symbol) {
		results = append(results, format("quadD", x, y))
	}
	if quadE(symbol) {
		results = append(results, format("quadE", x, y))
	}

	if len(results) == 0 {
		fmt.Println("Not a quad function")
		return
	}

	fmt.Println(strings.Join(results, " || "))
}

/* ================= helpers ================= */

func readStdin() string {
	scanner := bufio.NewScanner(os.Stdin)
	var s string
	for scanner.Scan() {
		s += scanner.Text() + "\n"
	}
	return s
}

func format(name string, x, y int) string {
	return fmt.Sprintf("[%s] [%d] [%d]", name, x, y)
}

/* ================= quadA ================= */

func quadA(l []string) bool {
	y := len(l)
	x := len(l[0])

	for r := 0; r < y; r++ {
		for c := 0; c < x; c++ {
			ch := l[r][c]

			switch {
			case (r == 0 || r == y-1) && (c == 0 || c == x-1):
				if ch != 'o' {
					return false
				}
			case r == 0 || r == y-1:
				if ch != '-' {
					return false
				}
			case c == 0 || c == x-1:
				if ch != '|' {
					return false
				}
			default:
				if ch != ' ' {
					return false
				}
			}
		}
	}
	return true
}

/* ================= quadB ================= */

func quadB(l []string) bool {
	y := len(l)
	x := len(l[0])

	for r := 0; r < y; r++ {
		for c := 0; c < x; c++ {
			ch := l[r][c]

			switch {
			case r == 0 && c == 0:
				if ch != '/' {
					return false
				}
			case r == 0 && c == x-1:
				if ch != '\\' {
					return false
				}
			case r == y-1 && c == 0:
				if ch != '\\' {
					return false
				}
			case r == y-1 && c == x-1:
				if ch != '/' {
					return false
				}
			case r == 0 || r == y-1 || c == 0 || c == x-1:
				if ch != '*' {
					return false
				}
			default:
				if ch != ' ' {
					return false
				}
			}
		}
	}
	return true
}

/* ================= quadC/D/E ================= */

func quadC(l []string) bool { return check(l, 'A', 'A', 'C', 'C') }
func quadD(l []string) bool { return check(l, 'A', 'C', 'A', 'C') }
func quadE(l []string) bool { return check(l, 'A', 'C', 'C', 'A') }

func check(l []string, tl, tr, bl, br byte) bool {
	y := len(l)
	x := len(l[0])

	for r := 0; r < y; r++ {
		for c := 0; c < x; c++ {
			ch := l[r][c]

			switch {
			case r == 0 && c == 0:
				if ch != tl {
					return false
				}
			case r == 0 && c == x-1:
				if ch != tr {
					return false
				}
			case r == y-1 && c == 0:
				if ch != bl {
					return false
				}
			case r == y-1 && c == x-1:
				if ch != br {
					return false
				}
			case r == 0 || r == y-1 || c == 0 || c == x-1:
				if ch != 'B' {
					return false
				}
			default:
				if ch != ' ' {
					return false
				}
			}
		}
	}
	return true
}
