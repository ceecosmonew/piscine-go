package main

import (
	"fmt"
	"practice/piscine"
)

func main() {

	result := []string{"a", "A", "1", "b", "B", "2", "c", "C", "3"}
	piscine.SortWordArr(result)

	fmt.Println(result)
	//------------------------------

	// result := []string{"a", "A", "1", "b", "B", "2", "c", "C", "3"}
	// 	piscine.SortWordArr(result)

	// 	fmt.Println(result)

	//----------------------------

	// tab1 := []string{"Hello", "how", "are", "you"}
	// 	tab2 := []string{"This","1", "is", "4", "you"}
	// 	answer1 := piscine.CountIf(piscine.IsNumeric, tab1)
	// 	answer2 := piscine.CountIf(piscine.IsNumeric, tab2)
	// 	fmt.Println(answer1)
	// 	fmt.Println(answer2)

	//--------------------------------
	// a1 := []string{"Hello", "how", "are", "you"}
	// a2 := []string{"This", "is", "4", "you"}

	// result1 := piscine.Any(piscine.IsNumeric, a1)
	// result2 := piscine.Any(piscine.IsNumeric, a2)

	// fmt.Println(result1)
	// fmt.Println(result2)

	//----------------------------------
	// a := []int{1, 2, 3, 4, 5, 6}
	// piscine.ForEach(piscine.PrintNbr, a)

	//-----------------------------
	// result := []string{"a", "A", "1", "b", "B", "2", "c", "C", "3"}
	// 	piscine.SortWordArr(result)

	// 	fmt.Println(result)

	//--------------------
	// tab1 := []string{"Hello", "how", "are", "you"}
	// tab2 := []string{"This","1", "is", "4", "you"}
	// answer1 := piscine.CountIf(piscine.IsNumeric, tab1)
	// answer2 := piscine.CountIf(piscine.IsNumeric, tab2)
	// fmt.Println(answer1)
	// fmt.Println(answer2)

	//---------------------------

	// a1 := []string{"Hello", "how", "are", "you"}
	// 	a2 := []string{"This", "is", "4", "you"}

	// 	result1 := piscine.Any(piscine.IsNumeric, a1)
	// 	result2 := piscine.Any(piscine.IsNumeric, a2)

	// 	fmt.Println(result1)
	// 	fmt.Println(result2)

	//----------------------
	// arg1 := 4
	// fmt.Println(piscine.Fibonacci(arg1))

	//---------

	// fmt.Println(piscine.IsUpper("HELLO"))
	// fmt.Println(piscine.IsUpper("HELLO!"))
	//-------------------------------

	// arg := 4
	// fmt.Println(piscine.IterativeFactorial(arg))

	//-------------------------------------

	// arg := 4
	// fmt.Println(piscine.RecursiveFactorial(arg))
	//--------------------------------

	// fmt.Println(piscine.IterativePower(4, 3))

	//----------------------

	// fmt.Println(piscine.RecursivePower(4, 3))

	//-------------------
	// arg1 := 4
	// fmt.Println(piscine.Fibonacci(arg1))

	//----------------------------------
	// fmt.Println(piscine.Sqrt(4))
	// fmt.Println(piscine.Sqrt(3))

	// fmt.Println(FindNextPrime(5))
	// fmt.Println(FindNextPrime(4))

	//-----------------------------------
	// fmt.Println(IsPrime(5))
	// fmt.Println(IsPrime(4))
	//--------------------------------------
	// fmt.Println(Sqrt(1))
	// fmt.Println(Sqrt(4))

}
