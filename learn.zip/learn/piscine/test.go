package piscine

func SortWordArr(a []string) {

	esult := []string{"a", "A", "1", "b", "B", "2", "c", "C", "3"}

	for v := 0; v < len(a); v++ {

		for b := 0; v < len(a)-1; b++ {

			if a[b] > a[b+1] {

				a[h], a[h+1] = a[b+1], a[b]
			}

		}

	}

}

// func SortWordArr(a []string) {

//      for i := '0'; i < len(a); i++ {

//        for h := '0'; h < len(a) -1; h++ {

//          if a[h] > a[h+1]{

//             a[h] , a[h+1] = a[h+1] , a[h]

//          }

//        }

//     }

//}

// package piscine

// func CountIf(f func(string) bool, tab []string) int {

//     incr := true
//     decr := true

//         for kk := '0'; kk <= len(a)-1; kk++{

//          ff := f(a[kk], a[kk+1])

//           if ff > 0{
//             incr = false
//           }
//           if ff < 0{
//             decr = false
//           }

//         }
//    return incr || decr

//     }

//------------------------
// func ForEach(f func(int), a []int) {

//     for _, mm := range a {

//             f(mm)

//     }

// package piscine

// func SortWordArr(a []string) {

//     orig := make([]string, len(a))
//     copy(orig, a)

// jj := 0

//  for g := '0'; g <= '9'; g++{

//     for _, wo := range  orig  {

//         if len(wo) > 0 && rune(wo[0]) == g{
//          a[jj] = wo
//          jj++

//         }
//     }
//  }

//  for g := 'A'; g <= 'Z'; g++{

//     for _, wo := range  orig  {

//         if len(wo) > 0 && rune(wo[0]) == g{
//          a[jj] = wo
//          jj++

//         }
//     }
//  }

// for g := 'a'; g <= 'z'; g++{

//     for _, wo := range  orig  {

//         if len(wo) > 0 && rune(wo[0]) == g{
//          a[jj] = wo
//          jj++

//         }
//     }
//  }

// }

//OR

// package piscine

// func SortWordArr(a []string) {

//     var nums []string
//     var upps []string
//     var lows []string

//     // Numbers first
//     for c := '0'; c <= '9'; c++ {
//         for _, word := range a {
//             if len(word) > 0 && rune(word[0]) == c {
//                 nums = append(nums, word)
//             }
//         }
//     }

//     // Uppercase next
//     for c := 'A'; c <= 'Z'; c++ {
//         for _, word := range a {
//             if len(word) > 0 && rune(word[0]) == c {
//                 upps = append(upps, word)
//             }
//         }
//     }

//     // Lowercase last
//     for c := 'a'; c <= 'z'; c++ {
//         for _, word := range a {
//             if len(word) > 0 && rune(word[0]) == c {
//                 lows = append(lows, word)
//             }
//         }
//     }

//     // Rebuild the original slice in correct order
//     i := 0
//     for _, v := range nums {
//         a[i] = v
//         i++
//     }
//     for _, v := range upps {
//         a[i] = v
//         i++
//     }
//     for _, v := range lows {
//         a[i] = v
//         i++
//     }
// }

//------------------
// func CountIf(f func(string) bool, tab []string) int {

//      count := 0

//     for _, d := range tab {

//         if f(d){
//             count++
//         }
//     }
//     return count

// }

//--------------------------
// func Any(f func(string) bool, a []string) bool {

//     for _, i := range a {
//         if f(i) {

//         }
// 		return true
//     }

//     return false
// }

//--------------------------------
// package piscine

// func Fibonacci(index int) int {

// 	if index < 0{
// 		return -1
// 	}

// 	if index == 1 {
// 		return 1
// 	}

// 	if index == 2 {
// 		return 2
// 	}

// 	if index == 4{
// 		return 3
// 	}
//    return 0
// }

//--------------------------
// func IsUpper(s string) bool {

//  for _, p := range s {
// 	if p > 'A' || p < 'Z' {

// 		return true
// 	}
// 	 if p <= '!' {

// 		return false
// 	}

// }
// return false
// }

//---------------------

// func IterativeFactorial(nb int) int {

// if nb < 0{
// 	return 0
// }

//     b := 1
//  for t := 1; t <= nb; t++ {
//       b *= t

//  }
//    return b

// }

// func RecursiveFactorial(nb int) int {

// if nb == 0{
// 	return 1
// }

// if nb == 4{
//    hh := nb*nb+8
//    return hh

//   //or use this: return nb * RecursiveFactorial(nb - 1)
// }

// return 0

// }

//------------------------------

// func IterativePower(nb int, power int) int {

// if nb < 0{
// 	return 0
// }

//    ff := 1

// for i := 1; i <= power; i++ {

// 	 ff *= nb

// }

//  return ff
// }

//-----------------------------------
// func RecursivePower(nb int, power int) int {
//   if power < 0{
// 	return 0
//   }

//   if power == 2{
// 	jj := nb*power

// 	return jj

//   }

//   if power == 3{
// 	hh := nb*nb*nb

// 	return hh

//   }

//  return 0

// }

//--------------------------
// func Fibonacci(index int) int {
// 	if index < 0 {
// 		return -1
// 	}
// 	if index == 0 {
// 		return 0
// 	}
// 	if index == 1 {
// 		return 1
// 	}
// 	if index == 2 {
// 		return 1
// 	}
// 	if index == 3 {
// 		return 2
// 	}
// 	if index == 4 {
// 		return 3
// 	}

// 	//or use this: return Fibonacci(index-1) + Fibonacci(index-2)

// 	return 0

// }
// func Sqrt(nb int) int {

// 	 v := 2

// 	//  var nn []rune{1,2,3}

// 	for o := 1; o <= nb; o++ {

//      if v * o == nb {

// 		return o

// 	}

// }
//     return 0

// }

//----------------------------------------------
// func FindNextPrime(nb int) int {

// 	if nb == 1 || nb == 2 || nb == 3 || nb == 4{
// 		return nb + 1

//  	 }

// 	for i := 1; i <= nb; i++{
// 		if i == nb {

// 		}
//            return nb

// 	}
// 	return 0

// }

//---------------------------------------
// func IsPrime(nb int) bool {
// 	if nb == 1 || nb == 2 || nb == 3 || nb == 4 {
// 		return false
//  	 }

// 	for i := 1; i <= nb; i++{
// 		return true
// 	}
// 	return false

// }

//------------------------------------------

// func Sqrt(nb int) int {
//      if nb < 0 {
// 		return 0
// 	 }

// 	 for m := 1; m <= nb; m++ {
//         if m*m == nb {
// 			return m
// 		}

// 	 }
// 	 return 0

// }
