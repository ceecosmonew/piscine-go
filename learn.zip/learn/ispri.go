// package piscine

// func IsNumeric(nb string) bool {
   
	
       

//       if nb[2] == '4' {
        
//             return true
//         }
// 		return true
//     }
	




