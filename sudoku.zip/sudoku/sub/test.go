package piscine

import (
	"fmt"
	"os"
)

var board [9][9]int

// ---------------------------------------------------------
// Parse the 9 input strings from command line
// ---------------------------------------------------------
func parseInput() {
	// We expect: go run . row1 row2 ... row9  (total 10 args)
	if len(os.Args) != 10 {
		fmt.Println("Usage: go run . row1 row2 ... row9")
		os.Exit(1)
	}

	// Convert each character of each row:
	// '.' becomes 0 (empty), numbers '1'..'9' become integers
	for i := 0; i < 9; i++ {
		row := os.Args[i+1] // the row string
		for j := 0; j < 9; j++ {
			if row[j] == '.' { // dot means empty
				board[i][j] = 0
			} else {
				board[i][j] = int(row[j] - '0') // convert char to digit
			}
		}
	}
}

// ---------------------------------------------------------
// Print the Sudoku board in clean format
// ---------------------------------------------------------
func printBoard() {
	for i := 0; i < 9; i++ {
		for j := 0; j < 9; j++ {
			fmt.Print(board[i][j])
			if j < 8 {
				fmt.Print(" ")
			}
		}
		fmt.Println()
	}
}

// ---------------------------------------------------------
// Check if placing "num" at board[row][col] is valid
// This checks:
//   - row contains no duplicates
//   - column contains no duplicates
//   - 3×3 box contains no duplicates
// ---------------------------------------------------------
func valid(row, col, num int) bool {

	// Check row and column
	for i := 0; i < 9; i++ {
		if board[row][i] == num || board[i][col] == num {
			return false
		}
	}

	// Find the top-left corner of the 3×3 box
	boxRow := (row / 3) * 3
	boxCol := (col / 3) * 3

	// Check the 3×3 box
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			if board[boxRow+r][boxCol+c] == num {
				return false
			}
		}
	}

	return true
}

// ---------------------------------------------------------
// Backtracking Sudoku solver
// Try filling empty cells one by one
// If a placement leads to a dead end, undo it and try next number
// ---------------------------------------------------------
func solve() bool {
	for r := 0; r < 9; r++ {
		for c := 0; c < 9; c++ {

			// If the cell is empty, try numbers 1-9
			if board[r][c] == 0 {

				for num := 1; num <= 9; num++ {
					if valid(r, c, num) {
						board[r][c] = num

						// Recursively continue
						if solve() {
							return true
						}

						// Undo move (backtrack)
						board[r][c] = 0
					}
				}

				// No valid number found -> Backtrack
				return false
			}
		}
	}

	// No empty cells left -> puzzle solved!
	return true
}
