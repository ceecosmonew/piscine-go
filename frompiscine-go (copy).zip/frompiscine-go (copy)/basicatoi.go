package piscine

func BasicAtoi(s string) int {
	result := 0

	for _, r := range s {
		result = result*10 + int(r-'0')
	}

	return result
}
