# 💻 the-final-cl-test

![01 Edu System](https://github.com/01-edu/public/assets/14015057/35560fed-34e6-42c8-a71b-71b0534b7ad7)

This repository contains all the necessary information to solve the `now-get-to-work` exercise of the [01 Edu System](https://github.com/01-edu) curriculum.
