package piscine

func BasicJoin(elems []string) string {
	result := ""
	for _, s := range elems {
		result += s
	}
	return result
}
