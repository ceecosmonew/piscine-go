#!/bin/bash

ls -l | sed '1d' | sed -n 'p;n'
